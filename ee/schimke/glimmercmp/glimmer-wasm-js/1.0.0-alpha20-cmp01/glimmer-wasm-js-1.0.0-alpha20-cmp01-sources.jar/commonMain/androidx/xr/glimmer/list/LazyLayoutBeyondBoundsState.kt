/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.xr.glimmer.list

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember

internal interface LazyLayoutBeyondBoundsState {

    val itemCount: Int

    val hasVisibleItems: Boolean

    val firstPlacedIndex: Int

    val lastPlacedIndex: Int

    fun itemsPerViewport(): Int
}

internal class GlimmerLazyListBeyondBoundsState(val state: GlimmerLazyListState) :
    LazyLayoutBeyondBoundsState {

    override val itemCount: Int
        get() = state.layoutInfo.totalItemsCount

    override val hasVisibleItems: Boolean
        get() = state.layoutInfo.visibleItemsInfo.isNotEmpty()

    override val firstPlacedIndex: Int
        get() = state.firstVisibleItemIndex

    override val lastPlacedIndex: Int
        get() = state.layoutInfo.visibleItemsInfo.last().index

    override fun itemsPerViewport(): Int {
        val layoutInfo = state.layoutInfoState.value
        if (layoutInfo.visibleItemsInfo.isEmpty()) return 0
        val viewportSize = layoutInfo.mainAxisViewportSize
        val averageItemSize = layoutInfo.visibleItemsAverageSize
        if (averageItemSize == 0) return 1
        return (viewportSize / averageItemSize).coerceAtLeast(1)
    }
}

@Composable
internal fun rememberGlimmerLazyListBeyondBoundsState(
    state: GlimmerLazyListState
): LazyLayoutBeyondBoundsState {
    return remember(state) { GlimmerLazyListBeyondBoundsState(state) }
}
